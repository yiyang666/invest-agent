"""SDK-owned PKCE scan-login protocol.

The browser only renders the server-provided URL. Session polling and the
one-time credential exchange always run in this Python process.
"""

from __future__ import annotations

import base64
import hashlib
import math
import secrets
import sys
import time
import webbrowser
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from . import LoginError, NetworkError, ServerError, TokenError
from ._http import DEFAULT_TIMEOUT
from ._http import post_json as _post_json
from ._http import post_json_with_headers as _post_json_with_headers
from ._login_lock import LoginLock


CREATE_PATH = "/v2/credential/scan-login/session"
POLL_PATH = "/v2/credential/scan-login/polling-status"
EXCHANGE_PATH = "/v2/credential/scan-login/exchange"
MAX_POLL_BACKOFF_SECONDS = 10.0

_monotonic = time.monotonic
_sleep = time.sleep
_wall_time = time.time


@dataclass(frozen=True)
class _Session:
    session_id: str
    browser_url: str
    poll_token: str
    expires_in: int
    poll_interval: float


def _base64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def generate_pkce() -> tuple[str, str]:
    """Return a local verifier and its RFC 7636 S256 challenge."""
    verifier = _base64url(secrets.token_bytes(32))
    challenge = _base64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return verifier, challenge


def run_scan_login(
    base_url: str,
    *,
    device_info: str,
    device_name: str,
    client_version: str,
    timeout: int,
) -> dict[str, Any]:
    """Create, display, poll, and exchange one scan-login session."""
    if isinstance(timeout, bool) or not isinstance(timeout, int) or timeout <= 0:
        raise ValueError("timeout must be a positive integer")

    code_verifier, code_challenge = generate_pkce()
    with LoginLock() as login_lock:
        response = _post_json(
            base_url,
            CREATE_PATH,
            {
                "deviceInfo": device_info,
                "deviceName": device_name,
                "clientVersion": client_version,
                "codeChallenge": code_challenge,
                "codeChallengeMethod": "S256",
            },
        )
        session = _parse_session(response)
        login_lock.update(
            session.browser_url,
            _wall_time() + float(session.expires_in),
        )
        _open_browser(session.browser_url)
        deadline = _monotonic() + min(float(timeout), float(session.expires_in))
        authorization_code = _poll_until_approved(
            base_url,
            session,
            deadline=deadline,
            clock=_monotonic,
            sleep=_sleep,
        )
        return _exchange(base_url, authorization_code, code_verifier)


def _parse_session(response: dict[str, Any]) -> _Session:
    """Validate a create-session response without echoing any secret value."""
    session_id = response.get("sessionId")
    browser_url = response.get("browserUrl")
    poll_token = response.get("sdkPollToken")
    expires_in = response.get("expiresIn")
    poll_interval = response.get("pollIntervalSeconds")

    strings = (session_id, browser_url, poll_token)
    if any(not isinstance(value, str) or not value for value in strings):
        raise LoginError("扫码会话响应不完整")
    if (
        isinstance(expires_in, bool)
        or not isinstance(expires_in, int)
        or expires_in <= 0
    ):
        raise LoginError("扫码会话响应不完整")
    if (
        isinstance(poll_interval, bool)
        or not isinstance(poll_interval, (int, float))
        or not math.isfinite(float(poll_interval))
        or float(poll_interval) <= 0
    ):
        raise LoginError("扫码会话响应不完整")

    return _Session(
        session_id=session_id,
        browser_url=browser_url,
        poll_token=poll_token,
        expires_in=expires_in,
        poll_interval=float(poll_interval),
    )


def _open_browser(browser_url: str) -> None:
    """Open the exact server URL, printing an interactive fallback on failure."""
    try:
        opened = webbrowser.open(browser_url)
    except Exception:
        opened = False
    if not opened:
        print(f"无法自动打开浏览器，请访问: {browser_url}", file=sys.stderr)


def _poll_until_approved(
    base_url: str,
    session: _Session,
    *,
    deadline: float,
    clock: Callable[[], float],
    sleep: Callable[[float], None],
) -> str:
    """Poll until approval or a terminal/timeout condition."""
    transient_delay = session.poll_interval
    body = {
        "sessionId": session.session_id,
        "sdkPollToken": session.poll_token,
    }

    while True:
        remaining = deadline - clock()
        if remaining <= 0:
            raise LoginError("扫码登录超时，请重新扫码")

        try:
            response, headers = _post_json_with_headers(
                base_url,
                POLL_PATH,
                body,
                timeout=min(DEFAULT_TIMEOUT, remaining),
            )
        except (NetworkError, ServerError):
            _sleep_with_deadline(
                min(transient_delay, MAX_POLL_BACKOFF_SECONDS),
                deadline=deadline,
                clock=clock,
                sleep=sleep,
            )
            transient_delay = min(
                transient_delay * 2.0, MAX_POLL_BACKOFF_SECONDS
            )
            continue
        except TokenError as error:
            raise LoginError("扫码登录状态查询被拒绝") from error

        transient_delay = session.poll_interval
        status = response.get("status")
        if status == "APPROVED":
            authorization_code = response.get("authorizationCode")
            if not isinstance(authorization_code, str) or not authorization_code:
                raise LoginError("扫码登录批准响应不完整")
            return authorization_code
        if status == "DENIED":
            raise LoginError("用户已拒绝扫码登录")
        if status == "EXPIRED":
            raise LoginError("扫码会话已过期，请重新扫码")
        if status not in ("CREATED", "SCANNED"):
            raise LoginError("扫码登录返回未知状态")

        delay = _retry_after(headers) or session.poll_interval
        _sleep_with_deadline(
            delay,
            deadline=deadline,
            clock=clock,
            sleep=sleep,
        )


def _retry_after(headers: Mapping[str, str]) -> float | None:
    raw_value = headers.get("Retry-After")
    if raw_value is None:
        return None
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    return value


def _sleep_with_deadline(
    delay: float,
    *,
    deadline: float,
    clock: Callable[[], float],
    sleep: Callable[[float], None],
) -> None:
    remaining = deadline - clock()
    if remaining <= 0:
        raise LoginError("扫码登录超时，请重新扫码")
    sleep(min(float(delay), remaining))


def _exchange(
    base_url: str,
    authorization_code: str,
    code_verifier: str,
) -> dict[str, Any]:
    """Exchange once, with one confirmation retry after response loss."""
    body = {
        "authorizationCode": authorization_code,
        "codeVerifier": code_verifier,
    }
    try:
        response = _post_json(base_url, EXCHANGE_PATH, body)
    except NetworkError:
        try:
            response = _post_json(base_url, EXCHANGE_PATH, body)
        except Exception as error:
            raise LoginError("凭证交换结果无法确认，请重新扫码") from error
    return _validate_exchange(response)


def _validate_exchange(response: dict[str, Any]) -> dict[str, Any]:
    required = (
        "accessKey",
        "secretKey",
        "privateKey",
        "publicKeyId",
        "refreshToken",
        "deviceHash",
    )
    if any(
        not isinstance(response.get(field), str) or not response.get(field)
        for field in required
    ):
        raise LoginError("凭证交换响应不完整")
    confirm_status = response.get("confirmStatus")
    format_version = response.get("credentialFormatVersion")
    if (
        isinstance(confirm_status, bool)
        or confirm_status != 1
        or isinstance(format_version, bool)
        or format_version != 2
    ):
        raise LoginError("凭证交换响应不完整")
    return dict(response)
