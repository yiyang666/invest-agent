"""Request schemas for virtual trade-account management."""

from __future__ import annotations

from .base import Field, ObjectSchema, non_empty_string, regex_string


GENERAL_TRADE_ID = regex_string(
    r"600[0-9]+", "a numeric general trade account starting with 600"
)

TRADE_ACCOUNT_LIST_SCHEMA = ObjectSchema(
    {"generaltradeId": Field(GENERAL_TRADE_ID, required=True)}
)
TRADE_ACCOUNT_CREATE_SCHEMA = ObjectSchema(
    {
        "generaltradeId": Field(GENERAL_TRADE_ID, required=True),
        "strategyName": Field(non_empty_string, required=True),
    }
)
