"""aijijin_sdk — minimal Python SDK for the gateway-auth V2 system (爱基金).

Public surface:
    init(init_token)                  — one-time setup, persists credentials
    get_work_token()                  — return a fresh Work Token
    exception types                   — see below

The default gateway URL is `BASE_URL` (sourced from `config.DEFAULT_GATEWAY_URL`).
To target a different environment (test / staging / prod), set the
`AIJIJIN_GATEWAY_URL` environment variable, or monkeypatch `BASE_URL` in tests.
"""

from __future__ import annotations

from ._error_codes import ErrorCode
from .config import DEFAULT_GATEWAY_URL, get_gateway_url


__version__ = "0.2.0"


# === Configuration ===

# Default gateway base URL. Override at runtime via the AIJIJIN_GATEWAY_URL env
# var, or in tests by monkeypatching this module attribute.
BASE_URL: str = DEFAULT_GATEWAY_URL
DEVICE_INFO_VERSION = "1"


def _gateway_url() -> str:
    import os

    if "AIJIJIN_GATEWAY_URL" in os.environ:
        return get_gateway_url()
    return BASE_URL


# === Exceptions ===

class AijijinError(Exception):
    """Base class for all aijijin_sdk exceptions."""


class InitError(AijijinError):
    """init() failed (bad init_token, network, or malformed response)."""


class CredentialsNotFoundError(AijijinError):
    """get_work_token() called before init(), or the credentials file was deleted."""


class CredentialsFormatError(AijijinError):
    """Credentials file is unparseable, has the wrong version, or is missing required fields."""


class TokenError(AijijinError):
    """RT or WT request was rejected by the gateway."""

    def __init__(
        self,
        message: str,
        *,
        code: "ErrorCode | int | None" = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


class NetworkError(AijijinError):
    """Transport-level failure (timeout, DNS, connection refused)."""

    def __init__(self, message: str, *, cause: BaseException | None = None) -> None:
        super().__init__(message)
        self.cause = cause


class ServerError(AijijinError):
    """Gateway returned a 5xx response."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class RefreshTokenExpiredError(AijijinError):
    """Refresh Token 缺失或已失效，需用户前往同花顺 App 获取新 RT 并写入配置文件。"""


_DEVICE_AUTHORIZATION_MSG = (
    "设备信息校验失败（错误码 1406）。"
    "请前往同花顺 App 复制新的提示词 / initToken 后，重新执行 aijijin_sdk.init(...)。"
)


class DeviceAuthorizationError(AijijinError):
    """设备信息校验失败（1406），需前往同花顺 App 复制新提示词 / initToken 并重新调用 init()。"""

    def __init__(self, message: str = _DEVICE_AUTHORIZATION_MSG) -> None:
        super().__init__(message)


# === Public API ===

def init(init_token: str, path: "str | None" = None) -> int:
    """Exchange a one-time init_token for a long-lived credential and persist to disk.

    Args:
        init_token: the one-time init token obtained from the 爱基金 APP.
        path: optional directory to store credentials.json in. Defaults to
              ~/.aijijin/. When given, it is also remembered across runs via the
              pointer file ~/.aijijin/location, so later get_work_token() calls
              resolve to the same directory without re-passing path.

    Returns:
        Device confirmation status: 0 means the user must confirm the device in
        the App; 1 means the device is already confirmed.

    Raises:
        InitError: init_token is invalid/expired, the network failed, or the
                   response was malformed.
        DeviceAuthorizationError: 设备注册返回 1406（设备信息无效），需用户去同花顺 App
                                   复制新的提示词 / initToken 后重新执行 aijijin_sdk.init(...)。
    """
    if not init_token:
        raise InitError("init_token must be non-empty")

    from ._credentials import (
        save as _credentials_save,
        resolve_path as _resolve_path,
        remember_dir as _remember_dir,
    )
    from ._http import post_json as _post_json
    from ._error_codes import DEVICE_REINITIALIZATION_CODES

    if path is not None:
        _remember_dir(path)
    creds_path = _resolve_path(path)

    try:
        response = _post_json(
            _gateway_url(),
            "/v2/credential/init",
            {"initToken": init_token},
        )
    except (NetworkError, ServerError) as e:
        raise InitError(f"init request failed: {e}") from e
    except TokenError as e:
        raise InitError(f"init rejected: {e}") from e

    creds = _build_creds_from_init_response(response)
    try:
        creds, confirm_status = _ensure_device_registered(creds)
    except (NetworkError, ServerError) as e:
        raise InitError(f"device register request failed: {e}") from e
    except TokenError as e:
        if isinstance(e.code, ErrorCode) and e.code in DEVICE_REINITIALIZATION_CODES:
            raise DeviceAuthorizationError() from e
        raise InitError(f"device register rejected: {e}") from e
    _credentials_save(creds, creds_path)
    print(f"凭证已写入: {creds_path}")
    return confirm_status


def _build_creds_from_init_response(response: dict) -> dict:
    """Validate an /v2/credential/init response and project it into the on-disk shape.

    """
    required = ("accessKey", "secretKey", "privateKey", "publicKeyId", "refreshToken")
    missing = [f for f in required if f not in response]
    if missing:
        raise InitError(f"malformed init response: missing {missing}")

    return {
        "api_key": response["accessKey"],
        "secret_key": response["secretKey"],
        "private_key": response["privateKey"],
        "public_key_id": response["publicKeyId"],
        "refresh_token": {"token": response["refreshToken"]},
        "device": None,
    }


def _build_device_block(device_hash: str, device_name: str, uid: str, device_type: str) -> dict:
    """Build the persisted device block, caching the collected uid for reuse."""
    import platform

    return {
        "device_hash": device_hash,
        "device_name": device_name,
        "uid": uid,
        "device_info_version": DEVICE_INFO_VERSION,
        "device_type": device_type,
        "platform": platform.system().lower(),
    }


def _ensure_device_registered(creds: dict) -> tuple[dict, int]:
    """Register the current device if needed；返回 (creds, confirm_status)。已注册路径 confirm_status=1。"""
    from . import _device

    device = creds.get("device")
    if isinstance(device, dict) and device.get("device_hash"):
        if device.get("uid"):
            return creds, 1
        # 旧凭证缺 uid 缓存：实时采集并回填，device_hash 保持不变。
        uid, device_type = _device.collect_uid()
        new_device = dict(device)
        new_device["uid"] = uid
        new_device.setdefault("device_type", device_type)
        new_creds = dict(creds)
        new_creds["device"] = new_device
        return new_creds, 1

    from ._token_manager import register_device as _register_device

    rt = creds.get("refresh_token")
    if not isinstance(rt, dict) or not rt.get("token"):
        raise RefreshTokenExpiredError(_RT_MISSING_MSG)
    rt_token = rt["token"]

    uid, device_type = _device.collect_uid()
    device_info = _device.build_device_info(uid, device_type)
    device_name = _device.device_display_name()
    device_hash, confirm_status = _register_device(
        _gateway_url(),
        creds["api_key"],
        creds["secret_key"],
        rt_token,
        device_info,
        device_name,
    )

    new_creds = dict(creds)
    new_creds["device"] = _build_device_block(device_hash, device_name, uid, device_type)
    return new_creds, confirm_status


_RT_MISSING_MSG = (
    "未找到有效的 Refresh Token。请前往同花顺理财 - 基金Skill 页面刷新本设备 Refresh Token，"
    "然后调用 aijijin_sdk.set_refresh_token(refreshToken) 写入配置文件。"
)
_RT_EXPIRED_MSG = (
    "Refresh Token 已失效。请前往同花顺理财 - 基金Skill 页面刷新本设备 Refresh Token，"
    "然后调用 aijijin_sdk.set_refresh_token(refreshToken) 写入配置文件后重试。"
)


def _acquire_work_token_internal(path: "str | None" = None) -> "tuple[str, str, dict | None]":
    """Acquire a Work Token, performing all side effects (load creds / ensure device / rotate RT).

    Returns (work_token, final_refresh_token, update_or_None). 服务端在客户端版本
    非最新时随响应返回 update；缺省或非 dict 时为 None。
    """
    from . import _device
    from ._credentials import (
        load as _credentials_load,
        save as _credentials_save,
        resolve_path as _resolve_path,
    )
    from ._token_manager import get_work_token as _get_work_token_internal
    from ._error_codes import (
        ErrorCode,
        REFRESH_TOKEN_RECOVERABLE_CODES,
        DEVICE_REINITIALIZATION_CODES,
    )

    creds_path = _resolve_path(path)
    loaded_creds = _credentials_load(creds_path)
    creds, confirm_status = _ensure_device_registered(loaded_creds)
    # 仅在设备块被新建/回填（register 路径或 uid 回填路径）时落盘；
    # 已注册且无变更时不重写文件，避免 4001/4002/4003 等失败时落盘。
    if creds is not loaded_creds:
        _credentials_save(creds, creds_path)
    _ = confirm_status  # 仅 init() 关心；get_work_token 始终视为已确认。

    device_block = creds["device"]
    device_info = _device.build_device_info(device_block["uid"], device_block["device_type"])
    device_hash = device_block["device_hash"]

    rt = creds.get("refresh_token")
    if not isinstance(rt, dict) or not rt.get("token"):
        raise RefreshTokenExpiredError(_RT_MISSING_MSG)
    rt_token = rt["token"]

    try:
        work_token, final_rt, update = _get_work_token_internal(
            _gateway_url(),
            rt_token,
            device_info,
            device_hash,
            version=__version__,
        )
    except TokenError as e:
        if isinstance(e.code, ErrorCode):
            if e.code in DEVICE_REINITIALIZATION_CODES:
                raise DeviceAuthorizationError() from e
            if e.code in REFRESH_TOKEN_RECOVERABLE_CODES:
                raise RefreshTokenExpiredError(_RT_EXPIRED_MSG) from e
        raise

    if final_rt != rt_token:
        new_creds = dict(creds)
        new_creds["refresh_token"] = {"token": final_rt}
        _credentials_save(new_creds, creds_path)

    return work_token, final_rt, update


def get_work_token(path: "str | None" = None) -> str:
    """Return a fresh Work Token for fund trading.

    直接使用持久化的 Refresh Token 调用 /v2/token/work。SDK 不在本地判断 RT
    是否过期——是否有效完全由服务端返回的错误码决定。命中 RT 失效错误码
    (1101/1102/1103) 时抛 RefreshTokenExpiredError，提示用户前往同花顺 App
    获取新 RT 并写入配置文件（见 set_refresh_token）。若服务端在响应中返回
    newRefreshToken，则轮换后落盘。

    Args:
        path: optional directory holding credentials.json. Must match the
              directory passed to init(). Defaults to ~/.aijijin/.

    Raises:
        CredentialsNotFoundError: init() was never called (or the file was deleted).
        CredentialsFormatError:   the credentials file is unparseable / wrong version.
        RefreshTokenExpiredError: RT 缺失或已失效，需用户更新 RT。
        DeviceAuthorizationError: 设备信息校验失败（1406），需用户去同花顺 App 复制
                                  新提示词 / initToken 后重新执行 aijijin_sdk.init(...)。
        TokenError:               gateway 因其他原因拒绝了 WT 请求。
        NetworkError:             transport-level failure.
    """
    return _acquire_work_token_internal(path)[0]


def set_refresh_token(token: str, path: "str | None" = None) -> None:
    """把用户从同花顺 App 获取的新 Refresh Token 写入配置文件。

    Args:
        token: 新的 Refresh Token（非空）。
        path: optional directory holding credentials.json. Defaults to ~/.aijijin/.

    Raises:
        ValueError:                token 为空。
        CredentialsNotFoundError:  配置文件不存在（需先 init()）。
        CredentialsFormatError:    配置文件不可解析 / 版本不符。
    """
    if not token:
        raise ValueError("token must be non-empty")

    from ._credentials import (
        load as _credentials_load,
        save as _credentials_save,
        resolve_path as _resolve_path,
    )

    creds_path = _resolve_path(path)
    creds = _credentials_load(creds_path)
    creds["refresh_token"] = {"token": token}
    _credentials_save(creds, creds_path)


__all__ = [
    "BASE_URL",
    "init",
    "get_work_token",
    "set_refresh_token",
    "AijijinError",
    "InitError",
    "CredentialsNotFoundError",
    "CredentialsFormatError",
    "TokenError",
    "RefreshTokenExpiredError",
    "DeviceAuthorizationError",
    "NetworkError",
    "ServerError",
    "ErrorCode",
]
