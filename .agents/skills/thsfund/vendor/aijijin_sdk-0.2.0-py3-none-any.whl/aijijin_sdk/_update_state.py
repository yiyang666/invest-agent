"""Dismissal persistence for getworktoken update notifications."""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Literal

from ._credentials import _default_path as _creds_default_path, _remembered_dir


DISMISSAL_FILENAME = "update_state.json"
SUPPORTED_VERSION = 1
TODAY_SNOOZE_HOURS = 24


def _resolve_dir(path: str | Path | None = None) -> Path:
    """Resolve the directory holding update_state.json.

    Precedence (与 credentials 一致):
    1. explicit path → <path>/update_state.json
    2. remembered directory (via location pointer) → <remembered>/update_state.json
    3. ~/.aijijin/update_state.json
    """
    if path is None:
        remembered = _remembered_dir()
        if remembered is not None:
            return remembered
        return _creds_default_path().parent
    return Path(path).expanduser()


def _state_path(path: str | Path | None = None) -> Path:
    return _resolve_dir(path) / DISMISSAL_FILENAME


def _load(path: Path | None = None) -> dict:
    p = path or _state_path()
    if not p.exists():
        return {"version": SUPPORTED_VERSION, "dismissals": {}}
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError:
        return {"version": SUPPORTED_VERSION, "dismissals": {}}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {"version": SUPPORTED_VERSION, "dismissals": {}}
    if not isinstance(data, dict):
        return {"version": SUPPORTED_VERSION, "dismissals": {}}
    dismissals = data.get("dismissals")
    if not isinstance(dismissals, dict):
        dismissals = {}
    return {"version": SUPPORTED_VERSION, "dismissals": dismissals}


def _save(state: dict, path: Path | None = None) -> None:
    p = path or _state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if os.name == "posix":
        os.chmod(tmp, 0o600)
    os.replace(tmp, p)


def is_dismissed(
    version: str,
    *,
    path: str | Path | None = None,
    clock: Callable[[], float] | None = None,
) -> bool:
    """Return True iff the update for `version` is currently dismissed."""
    if clock is None:
        clock = time.time
    state = _load(path)
    entry = state["dismissals"].get(version)
    if not isinstance(entry, dict):
        return False
    mode = entry.get("mode")
    if mode == "never":
        return True
    if mode == "today":
        snooze_until = entry.get("snooze_until")
        if not isinstance(snooze_until, str):
            return False
        try:
            until = datetime.fromisoformat(snooze_until)
        except ValueError:
            return False
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
        return datetime.fromtimestamp(clock(), tz=timezone.utc) < until
    return False


def dismiss(
    version: str,
    mode: Literal["today", "never"],
    *,
    path: str | Path | None = None,
    clock: Callable[[], float] | None = None,
) -> dict:
    """Record a dismissal entry; return the persisted entry."""
    if clock is None:
        clock = time.time
    state = _load(path)
    now = datetime.fromtimestamp(clock(), tz=timezone.utc)
    entry: dict[str, Any] = {
        "mode": mode,
        "dismissed_at": now.isoformat(),
    }
    if mode == "today":
        snooze_until = now + timedelta(hours=TODAY_SNOOZE_HOURS)
        entry["snooze_until"] = snooze_until.isoformat()
    state["dismissals"][version] = entry
    _save(state, path)
    return entry


def clear(version: str, *, path: str | Path | None = None) -> bool:
    """Remove the dismissal entry for `version`. Return True if removed."""
    state = _load(path)
    if version in state["dismissals"]:
        del state["dismissals"][version]
        _save(state, path)
        return True
    return False
