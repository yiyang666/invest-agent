"""Read/write the on-disk credentials file at ~/.aijijin/credentials.json.

The on-disk format is a flat JSON dict. The current schema (version 2) is:

    {
      "version": 2,
      "updated_at": "2026-06-22T10:30:00Z",
      "api_key": "ak-...",
      "secret_key": "sk-...",
      "private_key": "-----BEGIN PRIVATE KEY-----\n...",
      "public_key_id": "pk-...",
      "refresh_token": null | {"token": "rt-..."},
      "device": {
        "device_hash": "...",
        "device_name": "...",
        "uid": "...",
        "device_info_version": "1",
        "device_type": "...",
        "platform": "..."
      }
    }

The gateway URL is NOT stored here — it lives in the module-level `BASE_URL`
constant. The init endpoint also does not return it.

The file defaults to ~/.aijijin/credentials.json. Public API functions accept an
optional `path` **directory**; when given, the file is read/written as
`<path>/credentials.json` instead. A custom directory is remembered across runs
via the pointer file `~/.aijijin/location`; when no `path` is passed that pointer
is consulted before falling back to the default (see `resolve_path`).

Writes are atomic (write to .tmp, os.replace) and create parent directories.
File mode is 0600 on POSIX.
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SUPPORTED_VERSION = 2


REQUIRED_FIELDS = (
    "version",
    "updated_at",
    "api_key",
    "secret_key",
    "private_key",
    "public_key_id",
    "refresh_token",
    "device",
)


CREDENTIALS_FILENAME = "credentials.json"

# Pointer file living in the FIXED default directory. When it exists, it holds
# the custom credentials directory chosen at init() time. This is how a custom
# location is remembered across runs, cross-platform, without touching system
# environment variables (see `remember_dir` / `resolve_path`).
LOCATION_FILENAME = "location"


def _default_dir() -> Path:
    """Return the canonical, fixed default directory (never overridden)."""
    return Path.home() / ".aijijin"


def _default_path() -> Path:
    """Return the canonical default credentials file location."""
    return _default_dir() / CREDENTIALS_FILENAME


def _pointer_file() -> Path:
    """Return the location-pointer file inside the fixed default directory."""
    return _default_dir() / LOCATION_FILENAME


def _remembered_dir() -> Path | None:
    """Read the remembered custom directory from the pointer file, if any.

    Returns None when the pointer is absent, empty, or unreadable.
    """
    try:
        value = _pointer_file().read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return Path(value).expanduser() if value else None


def resolve_path(path: str | Path | None) -> Path:
    """Resolve the credentials file location from an optional directory.

    Precedence, highest first:

    1. explicit ``path`` argument → ``<path>/credentials.json``
    2. directory remembered in the pointer file → ``<remembered>/credentials.json``
    3. default ``~/.aijijin/credentials.json``

    ``~`` is expanded in cases 1 and 2.
    """
    if path is None:
        remembered = _remembered_dir()
        if remembered is not None:
            return remembered / CREDENTIALS_FILENAME
        return _default_path()
    return Path(path).expanduser() / CREDENTIALS_FILENAME


def remember_dir(path: str | Path) -> None:
    """Remember an explicit credentials directory across runs, cross-platform.

    Writes the directory into the pointer file ``~/.aijijin/location`` (in the
    fixed default directory), so later calls that omit ``path`` resolve to the
    same directory via `resolve_path`. Unlike an environment variable this needs
    no shell/registry manipulation and takes effect immediately in every process
    and on every platform.

    Best-effort: on write failure no exception propagates (the caller has still
    written credentials to the explicit path this run).
    """
    pointer = _pointer_file()
    try:
        pointer.parent.mkdir(parents=True, exist_ok=True)
        pointer.write_text(str(Path(path).expanduser()), encoding="utf-8")
    except OSError:
        pass


def _now_iso() -> str:
    # Use time.time() so the `frozen_clock` test fixture can override it.
    return datetime.fromtimestamp(time.time(), tz=timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )


def load(path: Path | None = None) -> dict[str, Any]:
    """Read and validate the credentials file.

    Args:
        path: override the default location (used by tests).

    Raises:
        CredentialsNotFoundError: file does not exist.
        CredentialsFormatError:   file is unparseable, wrong version, or missing required fields.
    """
    from . import CredentialsFormatError, CredentialsNotFoundError  # local import to avoid cycle

    p = path or _default_path()
    if not p.exists():
        raise CredentialsNotFoundError(f"credentials file not found: {p}")

    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as e:
        raise CredentialsFormatError(f"failed to read credentials file: {e}") from e

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise CredentialsFormatError(f"credentials file is not valid JSON: {e}") from e

    if not isinstance(data, dict):
        raise CredentialsFormatError("credentials file must be a JSON object")

    version = data.get("version")
    if version == 1:
        data = _migrate_v1_to_v2(data)
        version = data.get("version")

    if version != SUPPORTED_VERSION:
        raise CredentialsFormatError(
            f"unsupported credentials file version: {version!r} (expected {SUPPORTED_VERSION})"
        )

    missing = [f for f in REQUIRED_FIELDS if f not in data]
    if missing:
        raise CredentialsFormatError(f"credentials file missing required fields: {missing}")

    return data


def _migrate_v1_to_v2(data: dict[str, Any]) -> dict[str, Any]:
    """Return an in-memory v2 credentials dict from a v1 credentials dict."""
    migrated = dict(data)
    migrated["version"] = SUPPORTED_VERSION
    migrated.setdefault("device", None)
    return migrated


def save(creds: dict[str, Any], path: Path | None = None) -> None:
    """Write the credentials dict to disk (atomic, 0600 on POSIX).

    Sets `updated_at` to the current UTC time. Does not validate the structure
    beyond setting the version.
    """
    p = path or _default_path()
    p.parent.mkdir(parents=True, exist_ok=True)

    payload = dict(creds)
    payload["version"] = SUPPORTED_VERSION
    payload["updated_at"] = _now_iso()

    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # Restrict permissions on POSIX before the rename so the window
    # where the file is readable is as small as possible.
    if os.name == "posix":
        os.chmod(tmp, 0o600)

    os.replace(tmp, p)
