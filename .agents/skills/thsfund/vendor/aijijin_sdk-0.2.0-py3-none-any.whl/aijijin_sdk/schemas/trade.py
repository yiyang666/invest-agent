"""Request schemas for trade order query and revocation endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from aijijin_sdk.errors import ValidationError

from .base import (
    Field,
    ObjectSchema,
    bounded_integer,
    enum_string,
    non_empty_string,
    regex_string,
)

DATE = regex_string(r"[0-9]{8}", "a yyyyMMdd date")


def _validate_order_list(body: Dict[str, Any]) -> None:
    try:
        start = datetime.strptime(body["startDate"], "%Y%m%d")
        end = datetime.strptime(body["endDate"], "%Y%m%d")
    except ValueError:
        raise ValidationError("must be a real yyyyMMdd date", "startDate/endDate")
    if start > end:
        raise ValidationError("startDate must not be after endDate", "startDate")
    if body["offset"] == 1:
        if "lastAcceptTime" in body or "lastAppSheetSerialNo" in body:
            raise ValidationError("cursor fields are only valid after page 1", "offset")
    else:
        for name in ("lastAcceptTime", "lastAppSheetSerialNo"):
            if name not in body:
                raise ValidationError("{} is required after page 1".format(name), name)


ORDER_LIST_SCHEMA = ObjectSchema(
    {
        "offset": Field(bounded_integer(1, 2147483647), required=True),
        "limit": Field(bounded_integer(1, 200), default=20),
        "startDate": Field(DATE, required=True),
        "endDate": Field(DATE, required=True),
        "opBusinessCode": Field(
            enum_string(("buy", "sell", "aip", "change", "dividend", "other", "all")),
            default="all",
        ),
        "opProductType": Field(
            enum_string(
                (
                    "demand",
                    "time",
                    "normal_fund",
                    "advanced_financing",
                    "pension",
                    "all",
                )
            ),
            default="all",
        ),
        "queryProcessing": Field(bool, required=True),
        "lastAcceptTime": Field(non_empty_string),
        "lastAppSheetSerialNo": Field(non_empty_string),
    },
    cross_validate=_validate_order_list,
)
ORDER_DETAIL_SCHEMA = ObjectSchema(
    {"appSheetSerialNo": Field(non_empty_string, required=True)}
)
REVOKE_SCHEMA = ObjectSchema(
    {
        "operator": Field(non_empty_string, default="999"),
        "revokeAppSheetNo": Field(non_empty_string, required=True),
    }
)
