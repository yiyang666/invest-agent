"""Request schemas for fund purchase and redemption endpoints."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from aijijin_sdk.errors import ValidationError

from .base import (
    Field,
    ObjectSchema,
    array_of,
    decimal_string,
    enum_string,
    non_empty_string,
    regex_string,
)

FUND_CODE = regex_string(r"[0-9]{6}", "a six-digit fund code")
ACCOUNT_ID = non_empty_string
ORDER_ID = non_empty_string


def http_url(value: Any, path: str) -> str:
    value = non_empty_string(value, path)
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValidationError("must be an HTTP(S) URL", path)
    return value


AGREEMENT_SCHEMA = ObjectSchema(
    {
        "title": Field(non_empty_string, required=True),
        "agreementUrl": Field(http_url, required=True),
    }
)

SUBSCRIBE_INIT_SCHEMA = ObjectSchema(
    {"fundCode": Field(FUND_CODE, required=True)}
)
FEE_RULE_SCHEMA = ObjectSchema({"fundCode": Field(FUND_CODE, required=True)})
TRADE_TREATY_SCHEMA = ObjectSchema({"fundCode": Field(FUND_CODE, required=True)})
ACCOUNT_STATUS_SCHEMA = ObjectSchema(
    {"version": Field(non_empty_string, required=True)}
)
TRADE_RECORD_SCHEMA = ObjectSchema(
    {
        "agreements": Field(array_of(AGREEMENT_SCHEMA, min_length=1), required=True),
        "sourceType": Field(enum_string(("BUY",)), required=True),
    }
)
CHECK_BEFORE_TRADE_SCHEMA = ObjectSchema(
    {
        "applicationAmount": Field(decimal_string(positive=True), required=True),
        "fundCode": Field(FUND_CODE, required=True),
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
    }
)
BUY_SCHEMA = ObjectSchema(
    {
        "buyType": Field(enum_string(("0", "1")), required=True),
        "fundCode": Field(FUND_CODE, required=True),
        "money": Field(decimal_string(positive=True), required=True),
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
        # 协议留痕校验：每个 buy 请求需要带 AgreementRecord；外层 nullable，
        # 缺省或显式 null 等价于"未提供"，不发送给服务端。
        "extAttr": Field(
            ObjectSchema(
                {"AgreementRecord": Field(non_empty_string, required=True)}
            ),
            nullable=True,
        ),
    }
)
REDEEM_RENDER_SCHEMA = ObjectSchema(
    {
        "transactionAccountId": Field(ACCOUNT_ID, required=True),
        "fundCode": Field(FUND_CODE, required=True),
    }
)
REDEEM_SCHEMA = ObjectSchema(
    {
        "fundCode": Field(FUND_CODE, required=True),
        "redemptionType": Field(enum_string(("0", "1")), required=True),
        "shareVol": Field(decimal_string(positive=True), required=True),
        "transActionAccountId": Field(ACCOUNT_ID, required=True),
    }
)
