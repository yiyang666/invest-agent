"""Strict request schemas for business endpoints."""

from __future__ import annotations

from typing import Any, Dict

from .base import Field, ObjectSchema
from .fund import (
    ACCOUNT_STATUS_SCHEMA,
    BUY_SCHEMA,
    CHECK_BEFORE_TRADE_SCHEMA,
    FEE_RULE_SCHEMA,
    REDEEM_RENDER_SCHEMA,
    REDEEM_SCHEMA,
    SUBSCRIBE_INIT_SCHEMA,
    TRADE_RECORD_SCHEMA,
    TRADE_TREATY_SCHEMA,
)
from .holding import HOLDING_LIST_SCHEMA, WALLET_HOME_SCHEMA
from .trade import ORDER_DETAIL_SCHEMA, ORDER_LIST_SCHEMA, REVOKE_SCHEMA

SCHEMAS = {
    "wallet_home": WALLET_HOME_SCHEMA,
    "holding_list": HOLDING_LIST_SCHEMA,
    "subscribe_init": SUBSCRIBE_INIT_SCHEMA,
    "fee_rule": FEE_RULE_SCHEMA,
    "trade_treaty": TRADE_TREATY_SCHEMA,
    "account_status": ACCOUNT_STATUS_SCHEMA,
    "trade_record": TRADE_RECORD_SCHEMA,
    "check_before_trade": CHECK_BEFORE_TRADE_SCHEMA,
    "buy": BUY_SCHEMA,
    "redeem_render": REDEEM_RENDER_SCHEMA,
    "redeem": REDEEM_SCHEMA,
    "order_list": ORDER_LIST_SCHEMA,
    "order_detail": ORDER_DETAIL_SCHEMA,
    "revoke": REVOKE_SCHEMA,
}


def validate_request(name: str, value: Any) -> Dict[str, Any]:
    return SCHEMAS[name].validate(value)


__all__ = ["Field", "ObjectSchema", "SCHEMAS", "validate_request"]
