"""Small dependency-free request schema validator."""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Dict, Iterable, List, Optional

from aijijin_sdk.errors import ValidationError

MISSING = object()
Validator = Callable[[Any, str], Any]


class Field:
    def __init__(
        self,
        validator: Any,
        required: bool = False,
        default: Any = MISSING,
        nullable: bool = False,
    ) -> None:
        self.validator = validator
        self.required = required
        self.default = default
        self.nullable = nullable

    def validate(self, value: Any, path: str) -> Any:
        if value is None:
            if self.nullable:
                return None
            raise ValidationError("must not be null", path)
        if self.validator is int:
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValidationError("must be an integer", path)
            return value
        if self.validator is bool:
            if not isinstance(value, bool):
                raise ValidationError("must be a boolean", path)
            return value
        if self.validator is str:
            if not isinstance(value, str):
                raise ValidationError("must be a string", path)
            return value
        if isinstance(self.validator, ObjectSchema):
            return self.validator.validate(value, path)
        return self.validator(value, path)


class ObjectSchema:
    def __init__(
        self,
        fields: Dict[str, Field],
        cross_validate: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        self.fields = dict(fields)
        self.cross_validate = cross_validate

    def validate(self, value: Any, path: str = "") -> Dict[str, Any]:
        if not isinstance(value, dict):
            raise ValidationError("must be an object", path or None)
        for key in value:
            if key not in self.fields:
                raise ValidationError("unknown field", _join(path, key))
        result = {}
        for name, field in self.fields.items():
            field_path = _join(path, name)
            if name not in value:
                if field.default is not MISSING:
                    result[name] = field.default
                elif field.required:
                    raise ValidationError("field is required", field_path)
                continue
            result[name] = field.validate(value[name], field_path)
        if self.cross_validate is not None:
            self.cross_validate(result)
        return result


def _join(prefix: str, name: str) -> str:
    return name if not prefix else prefix + "." + name


def non_empty_string(value: Any, path: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValidationError("must be a non-empty string", path)
    return value


def enum_string(values: Iterable[str]) -> Validator:
    allowed = tuple(values)

    def validate(value: Any, path: str) -> str:
        value = non_empty_string(value, path)
        if value not in allowed:
            raise ValidationError(
                "must be one of {}".format(", ".join(allowed)), path
            )
        return value

    return validate


def regex_string(pattern: str, description: str) -> Validator:
    compiled = re.compile(pattern)

    def validate(value: Any, path: str) -> str:
        value = non_empty_string(value, path)
        if compiled.fullmatch(value) is None:
            raise ValidationError("must be {}".format(description), path)
        return value

    return validate


def decimal_string(positive: bool = False) -> Validator:
    pattern = re.compile(r"^(0|[1-9][0-9]*)(\.[0-9]+)?$")

    def validate(value: Any, path: str) -> str:
        if not isinstance(value, str) or pattern.fullmatch(value) is None:
            raise ValidationError("must be a decimal string without exponent", path)
        try:
            number = Decimal(value)
        except InvalidOperation:
            raise ValidationError("must be a valid decimal", path)
        if positive and number <= 0:
            raise ValidationError("must be greater than 0", path)
        return value

    return validate


def bounded_integer(minimum: int, maximum: int) -> Validator:
    def validate(value: Any, path: str) -> int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValidationError("must be an integer", path)
        if value < minimum or value > maximum:
            raise ValidationError(
                "must be between {} and {}".format(minimum, maximum), path
            )
        return value

    return validate


def array_of(
    item_schema: ObjectSchema, min_length: int = 0
) -> Validator:
    def validate(value: Any, path: str) -> List[Dict[str, Any]]:
        if not isinstance(value, list):
            raise ValidationError("must be an array", path)
        if len(value) < min_length:
            raise ValidationError(
                "must contain at least {} item(s)".format(min_length), path
            )
        return [
            item_schema.validate(item, "{}[{}]".format(path, index))
            for index, item in enumerate(value)
        ]

    return validate
