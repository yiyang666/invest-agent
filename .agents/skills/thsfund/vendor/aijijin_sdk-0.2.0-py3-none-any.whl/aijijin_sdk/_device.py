"""设备信息采集与设备指纹输入构造。

职责：
  - build_device_info() 产出确定性的 JSON 字符串（含稳定唯一标识 `uid` 与来源 `device_type`），
    服务端对**整串**计算 deviceHash。SDK 不本地计算哈希。
  - device_display_name() 返回展示名（如主机名），供 /v2/device/register 的 deviceName。
  - device_meta() 返回落盘用的非敏感元信息（platform / device_type），不含 uid 原文。

关键约束：
  - deviceInfo 必须逐字节可复现（固定序列化），否则服务端重算哈希会失配。
  - 易变字段（platform/arch/confidence）不放进 deviceInfo。
  - 设备唯一标识首次实时采集，随后缓存进凭证文件的 device 块（uid 字段），
    后续调用直接复用，避免重复的系统调用（尤其是 macOS 的 ioreg 子进程）。
"""

from __future__ import annotations

import json
import platform
import re
import socket
import subprocess
import uuid
from pathlib import Path


_SUBPROCESS_TIMEOUT = 1.0  # 系统命令采集超时（秒），失败即降级


def _windows_machine_guid() -> str | None:
    """读 HKLM\\SOFTWARE\\Microsoft\\Cryptography\\MachineGuid。"""
    try:
        import winreg  # type: ignore[import-not-found]

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
        return value or None
    except Exception:
        return None


def _macos_platform_uuid() -> str | None:
    """ioreg 解析 IOPlatformUUID。"""
    try:
        out = subprocess.run(
            ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
        ).stdout
    except Exception:
        return None
    match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
    return match.group(1) if match else None


def _linux_machine_id() -> str | None:
    """读 /etc/machine-id 或 /var/lib/dbus/machine-id。"""
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            value = Path(path).read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if value:
            return value
    return None


def _mac_hostname_fallback() -> str:
    """无稳定机器 ID 时的降级标识：MAC + 主机名。"""
    return f"{uuid.getnode():012x}-{socket.gethostname()}"


def collect_uid() -> tuple[str, str]:
    """返回 (uid, device_type)。

    按平台取最稳定的唯一标识；取不到则降级到 MAC+hostname。
    实时采集入口：结果由调用方缓存进凭证文件，避免重复的系统调用。
    """
    system = platform.system()
    if system == "Windows":
        guid = _windows_machine_guid()
        if guid:
            return guid, "windows_machine_guid"
    elif system == "Darwin":
        puid = _macos_platform_uuid()
        if puid:
            return puid, "macos_platform_uuid"
    elif system == "Linux":
        mid = _linux_machine_id()
        if mid:
            return mid, "linux_machine_id"
    return _mac_hostname_fallback(), "mac_hostname_fallback"


def build_device_info(uid: str, device_type: str) -> str:
    """确定性的 deviceInfo JSON 串：{"device_type":"...","uid":"..."}。

    服务端对整串计算 deviceHash，故序列化必须逐字节可复现。
    uid/device_type 由调用方传入（首次实时采集，之后取自凭证缓存）。
    """
    return json.dumps(
        {"uid": uid, "device_type": device_type},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def device_display_name() -> str:
    """展示名（主机名），供 register 的 deviceName 字段。"""
    return socket.gethostname() or "unknown"
