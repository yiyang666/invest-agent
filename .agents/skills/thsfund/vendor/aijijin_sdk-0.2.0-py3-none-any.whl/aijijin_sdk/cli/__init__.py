"""Command-line interface for aijijin_sdk."""
