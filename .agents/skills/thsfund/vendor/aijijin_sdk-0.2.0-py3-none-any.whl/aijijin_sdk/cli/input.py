"""Load and merge CLI JSON inputs."""

from __future__ import annotations

import json
from typing import Any, Dict, Mapping, Optional, TextIO

from aijijin_sdk.errors import InputError

UNSET = object()


def _parse_object(text: str, source: str) -> Dict[str, Any]:
    try:
        value = json.loads(text)
    except ValueError as exc:
        raise InputError("{} contains invalid JSON: {}".format(source, exc)) from exc
    if not isinstance(value, dict):
        raise InputError("top-level JSON value must be an object")
    return value


def load_and_merge(
    json_file: Optional[str],
    use_stdin: bool,
    inline_json: Optional[str],
    named: Mapping[str, Any],
    stdin: TextIO,
) -> Dict[str, Any]:
    if json_file and use_stdin:
        raise InputError("--json-file and --stdin are mutually exclusive")
    result = {}
    if json_file:
        try:
            with open(json_file, "r", encoding="utf-8") as handle:
                result.update(_parse_object(handle.read(), json_file))
        except OSError as exc:
            raise InputError("cannot read {}: {}".format(json_file, exc)) from exc
    elif use_stdin:
        result.update(_parse_object(stdin.read(), "stdin"))
    if inline_json is not None:
        result.update(_parse_object(inline_json, "--json"))
    for key, value in named.items():
        if value is not UNSET:
            result[key] = value
    return result