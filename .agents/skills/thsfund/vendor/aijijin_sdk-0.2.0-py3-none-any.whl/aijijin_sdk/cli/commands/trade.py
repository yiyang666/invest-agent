"""Trade query and revoke CLI commands."""

from __future__ import annotations

import argparse

from aijijin_sdk.cli.input import UNSET, load_and_merge
from aijijin_sdk.client import BusinessClient
from aijijin_sdk.endpoints import ENDPOINTS
from aijijin_sdk.schemas import validate_request


def _help_text(wire_name, named):
    endpoint = ENDPOINTS[wire_name]
    visibility = "protected" if endpoint.protected else "public"
    mappings = ", ".join(
        f"--{option.replace('_', '-')} -> {field}"
        for option, field in named.items()
    ) or "no named fields"
    return (
        f"{visibility} {endpoint.method} {endpoint.path}; "
        "accepts JSON via --json-file, --stdin, or --json; "
        f"named mappings: {mappings}; unknown fields are rejected; "
        "--dry-run performs no token/network access"
    )


HELP_OVERRIDES = {
    "revoke": "submit an order revocation (POST /openapi/ai/revoke) — non-retryable submission command",
}


def _add_input_options(parser):
    parser.add_argument("--json-file")
    parser.add_argument("--stdin", action="store_true", dest="use_stdin")
    parser.add_argument("--json", dest="inline_json")
    parser.add_argument("--dry-run", action="store_true")


def _integer(value):
    try:
        return int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("must be an integer")


def _execute(args, name, named):
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    return BusinessClient().request(ENDPOINTS[name], request)


def _execute_protected(args, name, named):
    """Protected endpoint: return (payload, update) tuple so the CLI top-level
    can surface the getworktoken update notification.

    dry-run still returns a plain dict (no update because no network call).
    """
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    client = BusinessClient()
    payload = client.request(ENDPOINTS[name], request)
    return payload, client.last_update


def register(subparsers):
    trade = subparsers.add_parser(
        "trade",
        help="trade query and revoke commands (protected endpoints)",
        description=(
            "Trade commands accept JSON through --json-file, --stdin, or --json; "
            "named options map to wire fields, unknown fields are rejected, and "
            "--dry-run performs no token/network access."
        ),
    )
    commands = trade.add_subparsers(dest="trade_command", required=True)

    # trade list
    listing = commands.add_parser(
        "list",
        help=_help_text(
            "order_list",
            {
                "offset": "offset",
                "limit": "limit",
                "start_date": "startDate",
                "end_date": "endDate",
                "business_code": "opBusinessCode",
                "product_type": "opProductType",
                "query_processing": "queryProcessing",
                "last_accept_time": "lastAcceptTime",
                "last_order_id": "lastAppSheetSerialNo",
            },
        ),
        description=_help_text(
            "order_list",
            {
                "offset": "offset",
                "limit": "limit",
                "start_date": "startDate",
                "end_date": "endDate",
                "business_code": "opBusinessCode",
                "product_type": "opProductType",
                "query_processing": "queryProcessing",
                "last_accept_time": "lastAcceptTime",
                "last_order_id": "lastAppSheetSerialNo",
            },
        ),
    )
    _add_input_options(listing)
    listing.add_argument("--offset", type=_integer, default=UNSET)
    listing.add_argument("--limit", type=_integer, default=UNSET)
    listing.add_argument("--start-date", default=UNSET)
    listing.add_argument("--end-date", default=UNSET)
    listing.add_argument("--business-code", default=UNSET)
    listing.add_argument("--product-type", default=UNSET)
    group = listing.add_mutually_exclusive_group()
    group.add_argument("--query-processing", action="store_true", dest="query_processing")
    group.add_argument("--no-query-processing", action="store_false", dest="query_processing")
    listing.set_defaults(query_processing=UNSET)
    listing.add_argument("--last-accept-time", default=UNSET)
    listing.add_argument("--last-order-id", default=UNSET)
    listing.set_defaults(
        handler=lambda args: _execute_protected(
            args,
            "order_list",
            {
                "offset": args.offset,
                "limit": args.limit,
                "startDate": args.start_date,
                "endDate": args.end_date,
                "opBusinessCode": args.business_code,
                "opProductType": args.product_type,
                "queryProcessing": args.query_processing,
                "lastAcceptTime": args.last_accept_time,
                "lastAppSheetSerialNo": args.last_order_id,
            },
        )
    )

    # trade detail
    detail = commands.add_parser(
        "detail",
        help=_help_text("order_detail", {"order_id": "appSheetSerialNo"}),
        description=_help_text("order_detail", {"order_id": "appSheetSerialNo"}),
    )
    _add_input_options(detail)
    detail.add_argument("--order-id", default=UNSET)
    detail.set_defaults(
        handler=lambda args: _execute_protected(
            args, "order_detail", {"appSheetSerialNo": args.order_id}
        )
    )

    # trade revoke
    revoke_help = HELP_OVERRIDES["revoke"]
    revoke_description = (
        f"{revoke_help}; "
        f"{_help_text('revoke', {'order_id': 'revokeAppSheetNo', 'operator': 'operator'})}"
    )
    revoke = commands.add_parser(
        "revoke",
        help=revoke_help,
        description=revoke_description,
    )
    _add_input_options(revoke)
    revoke.add_argument("--order-id", default=UNSET)
    revoke.add_argument("--operator", default=UNSET)
    revoke.set_defaults(
        handler=lambda args: _execute_protected(
            args,
            "revoke",
            {
                "operator": args.operator,
                "revokeAppSheetNo": args.order_id,
            },
        )
    )