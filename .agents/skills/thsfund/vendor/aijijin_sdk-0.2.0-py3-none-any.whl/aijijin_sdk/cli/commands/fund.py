"""Fund purchase, redemption, and auxiliary CLI commands."""

from __future__ import annotations

from aijijin_sdk.client import BusinessClient
from aijijin_sdk.endpoints import ENDPOINTS
from aijijin_sdk.schemas import validate_request
from aijijin_sdk.cli.input import UNSET, load_and_merge


def _add_input_options(parser):
    parser.add_argument("--json-file")
    parser.add_argument("--stdin", action="store_true", dest="use_stdin")
    parser.add_argument("--json", dest="inline_json")
    parser.add_argument("--dry-run", action="store_true")


_PROTECTED_WIRES = {"buy", "redeem", "redeem_render"}


def _execute(args, name, named):
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    return BusinessClient().request(ENDPOINTS[name], request)


def _execute_protected(args, name, named):
    """Same as _execute, but returns (payload, update) tuple so the CLI top-level
    can surface the getworktoken update notification.

    dry-run still returns a plain dict (no update because no network call).
    """
    merged = load_and_merge(
        args.json_file,
        args.use_stdin,
        args.inline_json,
        named,
        args.stdin,
    )
    request = validate_request(name, merged)
    if args.dry_run:
        return {"endpoint": name, "request": request}
    client = BusinessClient()
    payload = client.request(ENDPOINTS[name], request)
    return payload, client.last_update


def _add(parser, *, wire_name, named):
    for option, field in named.items():
        parser.add_argument(f"--{option.replace('_', '-')}", default=UNSET)
    dispatch = _execute_protected if wire_name in _PROTECTED_WIRES else _execute
    parser.set_defaults(
        handler=lambda args, w=wire_name, n=named: dispatch(
            args, w, {field: getattr(args, option) for option, field in n.items()}
        )
    )


def _register_buy(commands, named):
    """Buy 专属注册：在 COMMANDS 标准 4 字段之外追加 --agreement-record，
    该 flag 会被 CLI 内部包装为 extAttr.AgreementRecord（协议留痕校验）。
    """
    help_text = HELP_OVERRIDES["buy"]
    description = (
        f"{help_text}. JSON input via --json-file/--stdin/--json; "
        "unknown fields rejected; --dry-run performs no token/network access. "
        "--agreement-record 会被自动嵌套为 extAttr.AgreementRecord 用于合规留痕。"
    )
    sub = commands.add_parser("buy", help=help_text, description=description)
    _add_input_options(sub)
    for option, field in named.items():
        sub.add_argument(f"--{option.replace('_', '-')}", default=UNSET)
    sub.add_argument("--agreement-record", default=UNSET)

    def handler(args, n=named):
        merged = {field: getattr(args, option) for option, field in n.items()}
        record = getattr(args, "agreement_record", UNSET)
        if record is not UNSET:
            merged["extAttr"] = {"AgreementRecord": record}
        return _execute_protected(args, "buy", merged)

    sub.set_defaults(handler=handler)


COMMANDS = {
    "subscribe-init": ("subscribe_init", {"fund_code": "fundCode"}),
    "fee-rule": ("fee_rule", {"fund_code": "fundCode"}),
    "trade-treaty": ("trade_treaty", {"fund_code": "fundCode"}),
    "account-status": ("account_status", {"version": "version"}),
    "trade-record": ("trade_record", {}),
    "check-before-trade": (
        "check_before_trade",
        {
            "amount": "applicationAmount",
            "fund_code": "fundCode",
            "transaction_account_id": "transactionAccountId",
        },
    ),
    "buy": (
        "buy",
        {
            "buy_type": "buyType",
            "fund_code": "fundCode",
            "amount": "money",
            "transaction_account_id": "transactionAccountId",
        },
    ),
    "redeem-render": (
        "redeem_render",
        {
            "fund_code": "fundCode",
            "transaction_account_id": "transactionAccountId",
        },
    ),
    "redeem": (
        "redeem",
        {
            "fund_code": "fundCode",
            "redemption_type": "redemptionType",
            "share_vol": "shareVol",
            "transaction_account_id": "transActionAccountId",
        },
    ),
}


HELP_OVERRIDES = {
    "buy": "submit a purchase order (POST /openapi/ai/buy) — non-retryable submission command (network/5xx/business errors are never auto-retried)",
    "redeem": "submit a redemption (POST /openapi/ai/redemption/v2/redeem) — non-retryable submission command",
}


def _help_text(sub_name, wire_name, named):
    endpoint = ENDPOINTS[wire_name]
    visibility = "protected" if endpoint.protected else "public"
    mappings = ", ".join(
        f"--{option.replace('_', '-')} -> {field}"
        for option, field in named.items()
    ) or "no named fields"
    return f"{sub_name} ({visibility} endpoint): {mappings}"


def register(subparsers):
    fund = subparsers.add_parser(
        "fund",
        help="fund purchase, redemption, and helpers (protected/public endpoints)",
        description=(
            "Fund commands use --json-file, --stdin, or --json for JSON input; "
            "named options map to documented wire fields, unknown fields are rejected, "
            "and --dry-run performs no token/network access."
        ),
    )
    commands = fund.add_subparsers(dest="fund_command", required=True)
    for sub_name, (wire_name, named) in COMMANDS.items():
        if sub_name == "buy":
            _register_buy(commands, named)
            continue
        body = _help_text(sub_name, wire_name, named)
        help_text = HELP_OVERRIDES.get(sub_name, body)
        description = (
            f"{help_text}. "
            "JSON input via --json-file/--stdin/--json; "
            "unknown fields rejected; --dry-run performs no token/network access."
        )
        sub = commands.add_parser(sub_name, help=help_text, description=description)
        _add_input_options(sub)
        _add(sub, wire_name=wire_name, named=named)
