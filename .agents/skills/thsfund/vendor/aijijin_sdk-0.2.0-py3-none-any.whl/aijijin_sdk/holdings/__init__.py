"""Aggregated holdings views derived from raw gateway responses.

This subpackage centralizes the "interpret the gateway's holding response
and pick the records to show the user" logic that used to live in the
fund-holding-list skill. The CLI's `holding overview` command and any
programmatic consumer can reuse :func:`aggregate` directly.
"""

from .aggregate import (
    SHARE_CATEGORIES,
    aggregate,
    dec,
    extract_wallet,
    is_success,
    money,
    normalize_fund_record,
    pct,
    record_priority,
    select_final_fund_records,
    summarize_funds,
    top_records,
    unwrap_response,
)

__all__ = [
    "SHARE_CATEGORIES",
    "aggregate",
    "dec",
    "extract_wallet",
    "is_success",
    "money",
    "normalize_fund_record",
    "pct",
    "record_priority",
    "select_final_fund_records",
    "summarize_funds",
    "top_records",
    "unwrap_response",
]