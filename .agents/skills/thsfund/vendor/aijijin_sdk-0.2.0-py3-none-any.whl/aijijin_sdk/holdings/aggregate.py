"""Aggregate raw holding responses into a single user-facing overview.

The CLI's ``holding overview`` subcommand calls :func:`aggregate` after
fetching the wallet homepage and the seven shareCategory fund lists. The
function returns a plain dictionary ready to be serialized as JSON.

Design notes
------------

* The gateway sometimes returns the same fund under multiple
  ``transactionAccountId`` values (or duplicated across shareCategory
  calls). When an API-provided combined record exists (``combineFlag``
  in {1, Y, true, True} or present in ``fundPositonCombinedList``), we
  use it as the final display record and never sum display fields
  across duplicates.
* Wallet ``bankAccountShareList`` amounts are summed once.
* Fund totals (``totalAmount``, ``holdIncome``, ``newestIncome``) are
  summed from the final display records, **not** from any
  ``sumBuyAmount`` / ``sumHoldIncome`` field the gateway may provide.
* The CLI envelope (``{ok, data}``) and the legacy ``{json: ...}``
  wrapper are both accepted so callers can hand in either the raw CLI
  output or the already-unwrapped inner payload.
"""

from __future__ import annotations

from collections import OrderedDict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, Iterable, List, Tuple

SHARE_CATEGORIES: List[str] = ["01", "02", "03", "04", "05", "06", "07"]
SUM_FIELDS: List[str] = ["totalAmount", "holdIncome", "newestIncome"]
DISPLAY_FIELDS: List[str] = [
    "totalAmount",
    "holdIncome",
    "holdIncomeRate",
    "holdVol",
    "newestIncome",
]


# ---------- numeric helpers ----------


def dec(value: Any) -> Decimal:
    """Coerce *value* to :class:`Decimal`, defaulting to ``0`` on empty/invalid."""
    if value is None or value == "":
        return Decimal("0")
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return Decimal("0")


def money(value: Any) -> str:
    """Format *value* as a two-decimal monetary string (e.g. ``"12.34"``)."""
    return str(dec(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def pct(value: Any) -> str:
    """Format *value* as a percentage string (e.g. ``"12.34%"``); ``"-"`` for empty."""
    if value is None or value == "":
        return "-"
    return f"{(dec(value) * Decimal('100')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)}%"


# ---------- response parsing ----------


def unwrap_response(obj: Any) -> Dict[str, Any]:
    """Accept the CLI envelope ``{ok, data}``, the legacy ``{json: ...}`` wrapper, or raw dict."""
    if not isinstance(obj, dict):
        return {}
    if obj.get("ok") is True:
        data = obj.get("data")
        if isinstance(data, dict):
            return data
    if "json" in obj and isinstance(obj["json"], dict):
        return obj["json"]
    return obj


def is_success(obj: Dict[str, Any]) -> bool:
    """Return True when the gateway signals a successful response."""
    if not obj:
        return False
    if obj.get("status_code") == "0000":
        return True
    error = obj.get("error")
    return isinstance(error, dict) and error.get("id") == 0


# ---------- wallet ----------


def extract_wallet(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Return wallet payload plus the bank-card total."""
    resp = unwrap_response(raw)
    if not is_success(resp):
        return {"ok": False, "data": None, "bank_total": "0.00"}
    data = resp.get("data") or {}
    bank_total = sum(dec(x.get("totalShare")) for x in data.get("bankAccountShareList") or [])
    return {"ok": True, "data": data, "bank_total": money(bank_total)}


# ---------- fund selection ----------


def record_priority(record: Dict[str, Any]) -> Tuple[int, Decimal]:
    """Return a sort key that prefers API-provided combined records.

    Higher combineFlag score wins; ties broken by larger ``totalAmount``
    so the choice is deterministic. This only selects the final display
    record; it never sums display fields across duplicates.
    """
    combine_flag = str(record.get("combineFlag") or "")
    combined_score = 1 if combine_flag in {"1", "Y", "true", "True"} else 0
    return combined_score, dec(record.get("totalAmount"))


def select_final_fund_records(
    fund_responses: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], List[str], List[str]]:
    """Pick the final display record per ``fundCode`` and report category health.

    Returns ``(final_records, ok_categories, failed_categories)``.
    ``final_records`` is sorted by ``totalAmount`` descending.
    """
    candidates_by_code: "OrderedDict[str, List[Dict[str, Any]]]" = OrderedDict()
    ok_categories: List[str] = []
    failed_categories: List[str] = []

    for category in SHARE_CATEGORIES:
        raw = fund_responses.get(category)
        resp = unwrap_response(raw)
        if not is_success(resp):
            failed_categories.append(category)
            continue
        ok_categories.append(category)
        data = resp.get("data") or {}
        for record in data.get("fundPositonCombinedList") or []:
            code = str(record.get("fundCode") or "")
            if not code:
                continue
            candidates_by_code.setdefault(code, []).append(record)

    final_records: List[Dict[str, Any]] = []
    for code, records in candidates_by_code.items():
        chosen = max(records, key=record_priority)
        normalized = dict(chosen)
        normalized["duplicateRecordCount"] = len(records)
        normalized["displayFieldsSource"] = (
            "api_combined_record" if len(records) > 1 else "api_record"
        )
        final_records.append(normalized)

    final_records.sort(key=lambda r: dec(r.get("totalAmount")), reverse=True)
    return final_records, ok_categories, failed_categories


def summarize_funds(records: Iterable[Dict[str, Any]]) -> Dict[str, str]:
    """Sum ``totalAmount`` / ``holdIncome`` / ``newestIncome`` over the final records."""
    records = list(records)
    return {
        "fundCount": str(len(records)),
        "totalAmount": money(sum(dec(r.get("totalAmount")) for r in records)),
        "holdIncome": money(sum(dec(r.get("holdIncome")) for r in records)),
        "newestIncome": money(sum(dec(r.get("newestIncome")) for r in records)),
    }


def normalize_fund_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Render a final fund record into the display payload (money/pct strings, "待确认" state)."""
    hold_vol = dec(record.get("holdVol"))
    total_amount = dec(record.get("totalAmount"))
    return {
        "fundCode": record.get("fundCode"),
        "fundName": record.get("fundName"),
        "totalAmount": money(record.get("totalAmount")),
        "holdIncome": money(record.get("holdIncome")),
        "holdIncomeRate": pct(record.get("holdIncomeRate")),
        "holdVol": "待确认" if hold_vol == 0 and total_amount > 0 else money(record.get("holdVol")),
        "newestIncome": money(record.get("newestIncome")),
        "duplicateRecordCount": record.get("duplicateRecordCount", 1),
        "displayFieldsSource": record.get("displayFieldsSource", "api_record"),
        "raw": {field: record.get(field) for field in DISPLAY_FIELDS},
    }


def top_records(records: List[Dict[str, Any]], reverse: bool) -> List[Dict[str, Any]]:
    """Return the top/bottom 5 by ``holdIncome``, filtered to its sign."""
    if reverse:
        eligible = [r for r in records if dec(r.get("holdIncome")) > 0]
    else:
        eligible = [r for r in records if dec(r.get("holdIncome")) < 0]
    selected = sorted(
        eligible, key=lambda r: dec(r.get("holdIncome")), reverse=reverse
    )[:5]
    return [
        {
            "fundCode": r.get("fundCode"),
            "fundName": r.get("fundName"),
            "holdIncome": money(r.get("holdIncome")),
            "holdIncomeRate": pct(r.get("holdIncomeRate")),
        }
        for r in selected
    ]


# ---------- top-level aggregation ----------


def aggregate(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Build the full overview payload from raw wallet + 7 shareCategory responses.

    The returned dict is JSON-safe and contains:

    * ``wallet``: extracted wallet payload + bank total
    * ``fundApi.okCategories`` / ``fundApi.failedCategories``
    * ``fundSummary``: aggregated ``totalAmount`` / ``holdIncome`` / ``newestIncome``
    * ``funds``: per-fund display records (sorted by ``totalAmount`` desc)
    * ``topProfitFunds`` / ``topLossFunds``: ranked by ``holdIncome``
    """
    wallet = extract_wallet(payload.get("wallet") or {})
    final_records, ok_categories, failed_categories = select_final_fund_records(
        payload.get("funds") or {}
    )
    return {
        "wallet": wallet,
        "fundApi": {
            "okCategories": ok_categories,
            "failedCategories": failed_categories,
        },
        "fundSummary": summarize_funds(final_records),
        "funds": [normalize_fund_record(r) for r in final_records],
        "topProfitFunds": top_records(final_records, reverse=True),
        "topLossFunds": top_records(final_records, reverse=False),
    }