"""Thin HTTP wrapper.

`post_json` is the only thing the rest of the SDK uses to talk to the gateway.
It:
  - sends a JSON POST with Content-Type: application/json
  - parses the CommonResponse<T> envelope
  - returns `data` on success (HTTP 2xx + code == 0)
  - maps business errors (code != 0) to TokenError with an ErrorCode or raw int
  - maps transport-level errors to NetworkError

Timeouts: 10s default, overridable for tests.
"""

from __future__ import annotations

import json
from typing import Any

import requests

from . import NetworkError, ServerError, TokenError
from ._error_codes import parse_error_code


DEFAULT_TIMEOUT = 10.0


def post_json(
    base_url: str,
    path: str,
    body: dict[str, Any],
    *,
    timeout: float = DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """POST `body` to `{base_url}{path}`, return the parsed `data` dict on success.

    Raises:
        NetworkError: transport-level failure (timeout, DNS, connection refused).
                      The original exception is attached as `.cause`.
        ServerError:  HTTP 5xx, non-JSON body, or non-dict `data` on 2xx success.
        TokenError:   HTTP 4xx, or HTTP 2xx with business `code != 0`. `code` field
                      is mapped to ErrorCode (known) or raw int (unknown).
    """
    url = f"{base_url.rstrip('/')}{path}"
    try:
        response = requests.post(
            url,
            data=json.dumps(body, separators=(",", ":"), ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            timeout=timeout,
        )
    except requests.exceptions.RequestException as e:
        raise NetworkError(f"network failure: {e}", cause=e) from e

    return _parse_response(response)


def _parse_response(response: requests.Response) -> dict[str, Any]:
    """按 CommonResponse<T> 形态解包网关响应。

    成功：HTTP 2xx + code == 0 + data 是 dict → 返回 data
    业务错误：code != 0（HTTP 2xx 或 4xx 都可能） → TokenError(code=..., status_code=...)
    服务异常：HTTP 5xx、JSON 不可解析、payload 非 dict、data 非 dict → ServerError
    """
    try:
        raw_payload = response.json()
    except (ValueError, requests.exceptions.JSONDecodeError):
        raise ServerError(
            f"gateway returned non-JSON body (status={response.status_code})",
            status_code=response.status_code,
        )

    if isinstance(raw_payload, dict) and isinstance(raw_payload.get("data"), dict):
        inner = raw_payload["data"]
        if "code" in inner or "message" in inner:
            payload = inner
        else:
            payload = raw_payload
    else:
        payload = raw_payload

    status = response.status_code

    # HTTP 5xx 优先按 ServerError 处理
    if 500 <= status < 600:
        raise ServerError(f"gateway returned {status}", status_code=status)

    if not isinstance(payload, dict):
        if 200 <= status < 300:
            # 2xx 但响应不是 object —— 服务端畸形
            raise ServerError(
                f"gateway returned non-object JSON (status={status})",
                status_code=status,
            )
        # 4xx + 非 dict body → 业务错误（透出 HTTP 状态码）
        raise TokenError(
            f"gateway returned {status} with non-object body",
            code=parse_error_code(status),
            status_code=status,
        )

    raw_code = payload.get("code", 0)
    message = payload.get("message") or ""
    data = payload.get("data")

    if 200 <= status < 300:
        if raw_code == 0:
            # 业务成功
            if not isinstance(data, dict):
                raise ServerError(
                    f"gateway returned 2xx with code=0 but non-dict data (status={status})",
                    status_code=status,
                )
            return data
        # HTTP 2xx 但业务码非零 → 业务错误
        raise TokenError(
            message or "gateway business error",
            code=parse_error_code(raw_code),
            status_code=status,
        )

    # HTTP 4xx：业务错误
    if raw_code == 0:
        # body 残缺：用 HTTP 状态码作为 code 兜底（透出为 int）
        raise TokenError(
            message or f"gateway returned {status}",
            code=parse_error_code(status),
            status_code=status,
        )
    raise TokenError(
        message or "gateway error",
        code=parse_error_code(raw_code),
        status_code=status,
    )